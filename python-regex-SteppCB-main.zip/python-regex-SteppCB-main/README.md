# Python RegEx

Instructions to this assignment can be found [here](https://it3038c.github.io/modules/10/python-regex).

## Checklist

```md
- [x] This task is complete.
```

- [ ] All Unit tests passed.
- [ ] Filled out the self-evaluation.
- [ ] Filled out the self-reflection.

## Self-Evaluation

How many points out of 20 do you deserve on this assignment: `0-20`

## Self-Reflection
<!-- What did you learn that you found interesting -->

### How long it took you to finish this?
